<div id="header">
		<div class="logo">
			<a href="../index.php"><span>ParkUrCar |</a></span> <a href="index.php">Administration</a>
		</div>
	</div>

	<a href="#" class="mobile">MENU</a>
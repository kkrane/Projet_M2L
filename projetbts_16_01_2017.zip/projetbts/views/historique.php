<?php
require_once 'models/historique.php';
?>
	<body id="top">
        <section id="historique">
    		<div class="container">
    			<div class="row">
    				<div class="col-md-offset-3 col-md-10">
    				<h1>Historique de vos formations</h1>
    				<?php
                        $req = getHistorique();
    				    while($donnee = $req->fetch())
                        {
                         echo '<td scope="col" width="10%" name="titre" id="titre">'.$donnee['titre'].'</td>';
                        }
    				?>
    				</div>
    			</div>
    		</div>
    	</section>
    </body>

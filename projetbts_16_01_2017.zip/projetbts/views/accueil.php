<body id="top">


            <div class="container">
				<div class="row">
					<div class="col-md-12">
    					<h2 class="wow bounceIn" data-wow-offset="50" data-wow-delay="0.3s">CHERCHEZ UNE <span>FORMATION</span></h2>
    				</div>
                    <div class="col-md-4 col-sm-4 col-xs-12 wow fadeInLeft" data-wow-offset="50" data-wow-delay="0.6s">
                        <div class="media">
                            <div class="media-heading-wrapper">
                                <div class="media-object pull-left">
                                    <i class="fa fa-mobile"></i>
                                </div>
                                <h3 class="media-heading">FORMATION 1</h3>
                            </div>
                            <div class="media-body">
                                <p>Ce site permet la réservation en ligne de place de parking pour la société <a rel="nofollow" href="http://www.google.com" target="_parent">Parkcar</a>. Il s'agit d'un gestionnaire auquel vous pouvez avoir accès afin de gérer ou de demander une place de parking.</p>
                            </div>
                        </div>
                    </div>
					<div class="col-md-4 col-sm-4 col-xs-12 wow fadeInUp" data-wow-offset="50" data-wow-delay="0.9s">
						<div class="media">
							<div class="media-heading-wrapper">
								<div class="media-object pull-left">
									<i class="fa fa-car"></i>
								</div>
								<h3 class="media-heading">FORMATION 2</h3>
							</div>
							<div class="media-body">
								<p>En accord avec <a rel="nofollow" href="http://www.google.com">Parkcar</a> vous pourrez avoir accès à votre place de parking et savoir combien de temps cette place vous est attribuée. Pour cela, veuillez vous connecter avec vos identifiants ci dessous.</p>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-4 col-xs-12 wow fadeInRight" data-wow-offset="50" data-wow-delay="0.6s">
						<div class="media">
							<div class="media-heading-wrapper">
								<div class="media-object pull-left">
									<i class="fa fa-html5"></i>
								</div>
								<h3 class="media-heading">FORMATION 3</h3>
							</div>
							<div class="media-body">
								<p>Afin d'obtenir un compte sur <a rel="nofollow" href="http://www.google.com">Park your car</a> veuillez vous inscrire ci dessous. Nos admins analyserons votre demande avant de vous autorisez l'accès à votre nouveau compte.</p>
							</div>
						</div>
					</div>
				</div>
			</div>
    </body>
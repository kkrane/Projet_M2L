<?php

require "models/formation.php";
require "views/formation.php";

?>
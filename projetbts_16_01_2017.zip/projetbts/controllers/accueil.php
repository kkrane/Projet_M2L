<?php 
require "models/accueil.php";
require "views/accueil.php";
?>
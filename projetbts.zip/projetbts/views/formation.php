<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>Jacquie et Michel</title>
		<meta name="keywords" content="">
		<meta name="description" content="">
		<meta http-equiv="X-UA-Compatible" content="IE=Edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<link rel="stylesheet" href="../css/animate.min.css">
		<link rel="stylesheet" href="../css/bootstrap.min.css">
		<link rel="stylesheet" href="../css/font-awesome.min.css">
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="../css/templatemo-style.css">
		<script src="../js/jquery.js"></script>
        <script src="../includes/function.js"></script>
		<script src="../js/bootstrap.min.js"></script>
        <script src="../js/jquery.singlePageNav.min.js"></script>
		<script src="../js/typed.js"></script>
		<script src="../js/wow.min.js"></script>
		<script src="../js/custom.js"></script>
	</head>
	<body id="top">

		<!-- start preloader -->
		<div class="preloader">
			<div class="sk-spinner sk-spinner-wave">
     	 		<div class="sk-rect1"></div>
       			<div class="sk-rect2"></div>
       			<div class="sk-rect3"></div>
      	 		<div class="sk-rect4"></div>
      			<div class="sk-rect5"></div>
     		</div>
    	</div>
    	<!-- end preloader -->

        <!-- start header -->
        
            <nav class="navbar navbar-default templatemo-nav" role="navigation">
            <div class="container">
                <div class="navbar-header">
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon icon-bar"></span>
                        <span class="icon icon-bar"></span>
                        <span class="icon icon-bar"></span>
                    </button>
                    <a href="#" class="navbar-brand"> <img src="../images/logo.png" class="img-responsive" style="width: 50px; height=50px";> </a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="../index.php">ACCUEIL</a></li>
                        <li><a href="formation.php">FORMATION</a></li>
                        <li><a href="historique.php">HISTORIQUE</a></li>
                        <li><a href="connexion.php">DECONNEXION</a></li>
                    </ul>
                </div>
            </div>
        </nav>
            <div class="container">
				<div class="row">
					<div class="col-md-12">
    					<h2 class="wow bounceIn" data-wow-offset="50" data-wow-delay="0.3s">CHERCHEZ UNE <span>FORMATION</span></h2>
    				</div>
                    <div class="col-md-4 col-sm-4 col-xs-12 wow fadeInLeft" data-wow-offset="50" data-wow-delay="0.6s">
                        <div class="media">
                            <div class="media-heading-wrapper">
                                <div class="media-object pull-left">
                                    <i class="fa fa-mobile"></i>
                                </div>
                                <h3 class="media-heading">FORMATION 1</h3>
                            </div>
                            <div class="media-body">
                                <p>Ce site permet la réservation en ligne pour la société <a rel="nofollow" href="http://www.google.com" target="_parent">Jacquie</a>. Il s'agit d'un gestionnaire auquel vous pouvez avoir accès afin de gérer ou de demander une place.</p>
                            </div>
                        </div>
                    </div>
					<div class="col-md-4 col-sm-4 col-xs-12 wow fadeInUp" data-wow-offset="50" data-wow-delay="0.9s">
						<div class="media">
							<div class="media-heading-wrapper">
								<div class="media-object pull-left">
									<i class="fa fa-car"></i>
								</div>
								<h3 class="media-heading">FORMATION 2</h3>
							</div>
							<div class="media-body">
								<p>En accord avec <a rel="nofollow" href="http://www.google.com">Michel</a> vous pourrez avoir accès à tout et savoir combien de temps cette place vous est attribuée. Pour cela, veuillez vous connecter avec vos identifiants ci dessous.</p>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-4 col-xs-12 wow fadeInRight" data-wow-offset="50" data-wow-delay="0.6s">
						<div class="media">
							<div class="media-heading-wrapper">
								<div class="media-object pull-left">
									<i class="fa fa-html5"></i>
								</div>
								<h3 class="media-heading">FORMATION 3</h3>
							</div>
							<div class="media-body">
								<p>Afin d'obtenir un compte sur <a rel="nofollow" href="http://www.google.com">Pour vous</a> veuillez vous inscrire ci dessous. Nos admins analyserons votre demande avant de vous autorisez l'accès à votre nouveau compte.</p>
							</div>
						</div>
					</div>
				</div>
			</div>
    </body>
</html>